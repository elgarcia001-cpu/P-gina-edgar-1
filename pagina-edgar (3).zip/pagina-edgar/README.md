# Página de Edgar García

Página web personal hecha con HTML, CSS, JavaScript y Bootstrap 5.3.8.

**Autor:** Edgar Leonardo García Saldaña

## Contenido

- Menú de navegación que se colapsa en celular
- Carrusel de imágenes con indicadores
- Tarjetas de mis pasatiempos: caballos, videojuegos, casino y mercados
- Listas, tabla de planes y pie de página
- Tooltip, popover y toast de Bootstrap (en `script.js`)

## Archivos

| Archivo | Qué contiene |
| --- | --- |
| `index.html` | Estructura de la página |
| `style.css` | Estilos propios |
| `script.js` | Activa tooltips, popovers y el toast |
| `img/` | Imágenes de la página |

## Cómo verla

Abre `index.html` en el navegador.
